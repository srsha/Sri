const firebaseConfig = {
  apiKey: "AIzaSyCFL45nqAuzNWo-myYICH1qRYqUWLk9FR8",
  authDomain: "ogytadsearn.firebaseapp.com",
  databaseURL: "https://ogytadsearn-default-rtdb.firebaseio.com",
  projectId: "ogytadsearn",
  storageBucket: "ogytadsearn.appspot.com",
  messagingSenderId: "150615973394",
  appId: "1:150615973394:web:4bdb6c38391208069602cb",
  measurementId: "G-KZCCSKH090"
};
firebase.initializeApp(firebaseConfig);
